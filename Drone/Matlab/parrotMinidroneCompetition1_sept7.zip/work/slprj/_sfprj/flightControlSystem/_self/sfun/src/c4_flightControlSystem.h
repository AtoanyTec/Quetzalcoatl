#ifndef __c4_flightControlSystem_h__
#define __c4_flightControlSystem_h__

/* Forward Declarations */
#ifndef typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD
#define typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c4_tag_0K68mFBjQDo1WRxKPpRFgD c4_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC
#define typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c4_tag_P9BqU0OiPAu5sFhUNvbXPC c4_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG
#define typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c4_tag_a7TcNrdk5JZcy5uxGijaRG c4_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef typedef_c4_cell_1
#define typedef_c4_cell_1

typedef struct c4_tag_hIvE0H0Ni3BhTo6qVK2nUE c4_cell_1;

#endif                                 /* typedef_c4_cell_1 */

#ifndef typedef_c4_cell_2
#define typedef_c4_cell_2

typedef struct c4_tag_TM19LyJsa5LnbAbn5kdkNF c4_cell_2;

#endif                                 /* typedef_c4_cell_2 */

#ifndef typedef_c4_cell_3
#define typedef_c4_cell_3

typedef struct c4_tag_GUM52DLBwcDkJRKLV2tSz c4_cell_3;

#endif                                 /* typedef_c4_cell_3 */

#ifndef typedef_c4_cell_wrap_4
#define typedef_c4_cell_wrap_4

typedef struct c4_tag_y2anywF90yUI9j7qH5yd3E c4_cell_wrap_4;

#endif                                 /* typedef_c4_cell_wrap_4 */

#ifndef typedef_c4_cell_5
#define typedef_c4_cell_5

typedef struct c4_tag_4f3zucywOvoC0QgnMj36nF c4_cell_5;

#endif                                 /* typedef_c4_cell_5 */

#ifndef typedef_c4_cell_wrap_6
#define typedef_c4_cell_wrap_6

typedef struct c4_tag_ge1UD3YqHcNerzgtJ4AjXF c4_cell_wrap_6;

#endif                                 /* typedef_c4_cell_wrap_6 */

#ifndef typedef_c4_cell_7
#define typedef_c4_cell_7

typedef struct c4_tag_EX2wxrf7UhZ6FVbfRZyo7B c4_cell_7;

#endif                                 /* typedef_c4_cell_7 */

#ifndef typedef_c4_cell_8
#define typedef_c4_cell_8

typedef struct c4_tag_wvqtwQNAx0JJ5IpvMHRcsG c4_cell_8;

#endif                                 /* typedef_c4_cell_8 */

#ifndef typedef_c4_cell_9
#define typedef_c4_cell_9

typedef struct c4_tag_awFMsYYWj01uO3vmLPQJOE c4_cell_9;

#endif                                 /* typedef_c4_cell_9 */

#ifndef typedef_c4_cell_10
#define typedef_c4_cell_10

typedef struct c4_tag_WYClaNMLzsYbJFiV2mng6F c4_cell_10;

#endif                                 /* typedef_c4_cell_10 */

#ifndef typedef_c4_cell_wrap_0
#define typedef_c4_cell_wrap_0

typedef struct c4_tag_L5JvjW1A13FyCQi5N783sB c4_cell_wrap_0;

#endif                                 /* typedef_c4_cell_wrap_0 */

#ifndef typedef_c4_cell_11
#define typedef_c4_cell_11

typedef struct c4_tag_BoX4lGjW7CLGNTo2OWmlp c4_cell_11;

#endif                                 /* typedef_c4_cell_11 */

#ifndef typedef_c4_cell_12
#define typedef_c4_cell_12

typedef struct c4_tag_6CsBRVljdCQyAxGT7eZM3E c4_cell_12;

#endif                                 /* typedef_c4_cell_12 */

#ifndef typedef_c4_cell_14
#define typedef_c4_cell_14

typedef struct c4_tag_URxaCoPZWr69Oy7fwnFxl c4_cell_14;

#endif                                 /* typedef_c4_cell_14 */

#ifndef typedef_c4_cell_15
#define typedef_c4_cell_15

typedef struct c4_tag_yMfj6323Zqv19VFnWGoHjH c4_cell_15;

#endif                                 /* typedef_c4_cell_15 */

#ifndef typedef_c4_cell_17
#define typedef_c4_cell_17

typedef struct c4_tag_9SoYFOHTFNVnYR44IKzdJH c4_cell_17;

#endif                                 /* typedef_c4_cell_17 */

#ifndef typedef_c4_cell_16
#define typedef_c4_cell_16

typedef struct c4_tag_fmW94SyqNuqwvLGV2qfkpE c4_cell_16;

#endif                                 /* typedef_c4_cell_16 */

#ifndef typedef_c4_cell_18
#define typedef_c4_cell_18

typedef struct c4_tag_ps6xcYPd6Y7F0F1cJs8YU c4_cell_18;

#endif                                 /* typedef_c4_cell_18 */

#ifndef typedef_c4_cell_19
#define typedef_c4_cell_19

typedef struct c4_tag_xrIszVtjD7x2xDQJhvqr2E c4_cell_19;

#endif                                 /* typedef_c4_cell_19 */

#ifndef typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD
#define typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c4_tag_tP4ysjhyvuYk36JuHDg8bD c4_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef typedef_c4_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c4_s_ynaaIE6q9xznGBkza31TCF

typedef struct c4_tag_ynaaIE6q9xznGBkza31TCF c4_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c4_s_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c4_s_y30bjXPnZrp2waraWnJSvH
#define typedef_c4_s_y30bjXPnZrp2waraWnJSvH

typedef struct c4_tag_y30bjXPnZrp2waraWnJSvH c4_s_y30bjXPnZrp2waraWnJSvH;

#endif                                 /* typedef_c4_s_y30bjXPnZrp2waraWnJSvH */

#ifndef typedef_c4_s_lFc4yenLpnRlydRiCMxaZD
#define typedef_c4_s_lFc4yenLpnRlydRiCMxaZD

typedef struct c4_tag_lFc4yenLpnRlydRiCMxaZD c4_s_lFc4yenLpnRlydRiCMxaZD;

#endif                                 /* typedef_c4_s_lFc4yenLpnRlydRiCMxaZD */

#ifndef typedef_c4_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c4_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c4_tag_BrRdqYMft44ulwR1A7rKqF c4_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c4_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c4_s_zhWislg2JXfOJCG0FlayVG
#define typedef_c4_s_zhWislg2JXfOJCG0FlayVG

typedef struct c4_tag_zhWislg2JXfOJCG0FlayVG c4_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* typedef_c4_s_zhWislg2JXfOJCG0FlayVG */

#ifndef typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF
#define typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c4_tag_lnEOVMt12CNg5nSw1iwvNF c4_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC
#define typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c4_tag_Uq8YUzQmSy3K1TONPeIAhC c4_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF
#define typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c4_tag_i8jNnI3x8wo4JAox5HV9WF c4_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef typedef_c4_s_dV11HShs2d9BqwRJb6HgvD
#define typedef_c4_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c4_tag_dV11HShs2d9BqwRJb6HgvD c4_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* typedef_c4_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef typedef_c4_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c4_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c4_tag_HSHOljOSgF7qDZeWd2IfH c4_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c4_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c4_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c4_s_HOps0FrfA6RiWumqewPwZD

typedef struct c4_tag_HOps0FrfA6RiWumqewPwZD c4_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c4_s_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c4_s_23YJI910RYCWhAsXw5RjrG
#define typedef_c4_s_23YJI910RYCWhAsXw5RjrG

typedef struct c4_tag_23YJI910RYCWhAsXw5RjrG c4_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* typedef_c4_s_23YJI910RYCWhAsXw5RjrG */

#ifndef typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c4_tag_i3ZGqykvgqQLsMCH6x4OBH c4_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB
#define typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c4_tag_u4ui3JwwaZ1jYzDQeNl7gB c4_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef typedef_c4_s_lv60kHidgCVN68cHDjBCkF
#define typedef_c4_s_lv60kHidgCVN68cHDjBCkF

typedef struct c4_tag_lv60kHidgCVN68cHDjBCkF c4_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* typedef_c4_s_lv60kHidgCVN68cHDjBCkF */

#ifndef typedef_c4_s_fnNBZRcViWKJIkyfK13VxD
#define typedef_c4_s_fnNBZRcViWKJIkyfK13VxD

typedef struct c4_tag_fnNBZRcViWKJIkyfK13VxD c4_s_fnNBZRcViWKJIkyfK13VxD;

#endif                                 /* typedef_c4_s_fnNBZRcViWKJIkyfK13VxD */

#ifndef typedef_c4_s_aArV2XTcNncafn1rtkY7sE
#define typedef_c4_s_aArV2XTcNncafn1rtkY7sE

typedef struct c4_tag_aArV2XTcNncafn1rtkY7sE c4_s_aArV2XTcNncafn1rtkY7sE;

#endif                                 /* typedef_c4_s_aArV2XTcNncafn1rtkY7sE */

#ifndef typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D
#define typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D

typedef struct c4_tag_2BS9SxHF6FwtuvnmplIf4D c4_s_2BS9SxHF6FwtuvnmplIf4D;

#endif                                 /* typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D */

#ifndef typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF
#define typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF

typedef struct c4_tag_IZ4td7h7wPpJ1lGa4DnYYF c4_s_IZ4td7h7wPpJ1lGa4DnYYF;

#endif                                 /* typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF */

/* Type Definitions */
#ifndef struct_c4_tag_0K68mFBjQDo1WRxKPpRFgD
#define struct_c4_tag_0K68mFBjQDo1WRxKPpRFgD

struct c4_tag_0K68mFBjQDo1WRxKPpRFgD
{
  int32_T f1;
  int32_T f2;
};

#endif                                 /* struct_c4_tag_0K68mFBjQDo1WRxKPpRFgD */

#ifndef typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD
#define typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c4_tag_0K68mFBjQDo1WRxKPpRFgD c4_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* typedef_c4_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef struct_c4_tag_P9BqU0OiPAu5sFhUNvbXPC
#define struct_c4_tag_P9BqU0OiPAu5sFhUNvbXPC

struct c4_tag_P9BqU0OiPAu5sFhUNvbXPC
{
  c4_s_0K68mFBjQDo1WRxKPpRFgD _data;
};

#endif                                 /* struct_c4_tag_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC
#define typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c4_tag_P9BqU0OiPAu5sFhUNvbXPC c4_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* typedef_c4_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef struct_c4_tag_a7TcNrdk5JZcy5uxGijaRG
#define struct_c4_tag_a7TcNrdk5JZcy5uxGijaRG

struct c4_tag_a7TcNrdk5JZcy5uxGijaRG
{
  char_T f1[7];
  char_T f2[7];
};

#endif                                 /* struct_c4_tag_a7TcNrdk5JZcy5uxGijaRG */

#ifndef typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG
#define typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c4_tag_a7TcNrdk5JZcy5uxGijaRG c4_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* typedef_c4_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef struct_c4_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define struct_c4_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c4_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* struct_c4_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef typedef_c4_cell_1
#define typedef_c4_cell_1

typedef struct c4_tag_hIvE0H0Ni3BhTo6qVK2nUE c4_cell_1;

#endif                                 /* typedef_c4_cell_1 */

#ifndef struct_c4_tag_TM19LyJsa5LnbAbn5kdkNF
#define struct_c4_tag_TM19LyJsa5LnbAbn5kdkNF

struct c4_tag_TM19LyJsa5LnbAbn5kdkNF
{
  char_T f1[5];
  char_T f2[5];
  char_T f3[7];
  char_T f4[7];
  char_T f5[3];
  char_T f6[9];
};

#endif                                 /* struct_c4_tag_TM19LyJsa5LnbAbn5kdkNF */

#ifndef typedef_c4_cell_2
#define typedef_c4_cell_2

typedef struct c4_tag_TM19LyJsa5LnbAbn5kdkNF c4_cell_2;

#endif                                 /* typedef_c4_cell_2 */

#ifndef struct_c4_tag_GUM52DLBwcDkJRKLV2tSz
#define struct_c4_tag_GUM52DLBwcDkJRKLV2tSz

struct c4_tag_GUM52DLBwcDkJRKLV2tSz
{
  char_T f1[6];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[5];
  char_T f6[6];
};

#endif                                 /* struct_c4_tag_GUM52DLBwcDkJRKLV2tSz */

#ifndef typedef_c4_cell_3
#define typedef_c4_cell_3

typedef struct c4_tag_GUM52DLBwcDkJRKLV2tSz c4_cell_3;

#endif                                 /* typedef_c4_cell_3 */

#ifndef struct_c4_tag_y2anywF90yUI9j7qH5yd3E
#define struct_c4_tag_y2anywF90yUI9j7qH5yd3E

struct c4_tag_y2anywF90yUI9j7qH5yd3E
{
  char_T f1[9];
};

#endif                                 /* struct_c4_tag_y2anywF90yUI9j7qH5yd3E */

#ifndef typedef_c4_cell_wrap_4
#define typedef_c4_cell_wrap_4

typedef struct c4_tag_y2anywF90yUI9j7qH5yd3E c4_cell_wrap_4;

#endif                                 /* typedef_c4_cell_wrap_4 */

#ifndef struct_c4_tag_4f3zucywOvoC0QgnMj36nF
#define struct_c4_tag_4f3zucywOvoC0QgnMj36nF

struct c4_tag_4f3zucywOvoC0QgnMj36nF
{
  char_T f1[4];
  char_T f2[5];
  char_T f3[5];
  char_T f4[6];
  char_T f5[5];
  char_T f6[6];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* struct_c4_tag_4f3zucywOvoC0QgnMj36nF */

#ifndef typedef_c4_cell_5
#define typedef_c4_cell_5

typedef struct c4_tag_4f3zucywOvoC0QgnMj36nF c4_cell_5;

#endif                                 /* typedef_c4_cell_5 */

#ifndef struct_c4_tag_ge1UD3YqHcNerzgtJ4AjXF
#define struct_c4_tag_ge1UD3YqHcNerzgtJ4AjXF

struct c4_tag_ge1UD3YqHcNerzgtJ4AjXF
{
  char_T f1[6];
};

#endif                                 /* struct_c4_tag_ge1UD3YqHcNerzgtJ4AjXF */

#ifndef typedef_c4_cell_wrap_6
#define typedef_c4_cell_wrap_6

typedef struct c4_tag_ge1UD3YqHcNerzgtJ4AjXF c4_cell_wrap_6;

#endif                                 /* typedef_c4_cell_wrap_6 */

#ifndef struct_c4_tag_EX2wxrf7UhZ6FVbfRZyo7B
#define struct_c4_tag_EX2wxrf7UhZ6FVbfRZyo7B

struct c4_tag_EX2wxrf7UhZ6FVbfRZyo7B
{
  char_T f1[9];
  char_T f2[9];
  char_T f3[8];
  char_T f4[4];
  char_T f5[4];
  char_T f6[4];
  char_T f7[4];
};

#endif                                 /* struct_c4_tag_EX2wxrf7UhZ6FVbfRZyo7B */

#ifndef typedef_c4_cell_7
#define typedef_c4_cell_7

typedef struct c4_tag_EX2wxrf7UhZ6FVbfRZyo7B c4_cell_7;

#endif                                 /* typedef_c4_cell_7 */

#ifndef struct_c4_tag_wvqtwQNAx0JJ5IpvMHRcsG
#define struct_c4_tag_wvqtwQNAx0JJ5IpvMHRcsG

struct c4_tag_wvqtwQNAx0JJ5IpvMHRcsG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[11];
  char_T f5[7];
};

#endif                                 /* struct_c4_tag_wvqtwQNAx0JJ5IpvMHRcsG */

#ifndef typedef_c4_cell_8
#define typedef_c4_cell_8

typedef struct c4_tag_wvqtwQNAx0JJ5IpvMHRcsG c4_cell_8;

#endif                                 /* typedef_c4_cell_8 */

#ifndef struct_c4_tag_awFMsYYWj01uO3vmLPQJOE
#define struct_c4_tag_awFMsYYWj01uO3vmLPQJOE

struct c4_tag_awFMsYYWj01uO3vmLPQJOE
{
  char_T f1[8];
  char_T f2[9];
  char_T f3[9];
  char_T f4[3];
  char_T f5[4];
  char_T f6[4];
};

#endif                                 /* struct_c4_tag_awFMsYYWj01uO3vmLPQJOE */

#ifndef typedef_c4_cell_9
#define typedef_c4_cell_9

typedef struct c4_tag_awFMsYYWj01uO3vmLPQJOE c4_cell_9;

#endif                                 /* typedef_c4_cell_9 */

#ifndef struct_c4_tag_WYClaNMLzsYbJFiV2mng6F
#define struct_c4_tag_WYClaNMLzsYbJFiV2mng6F

struct c4_tag_WYClaNMLzsYbJFiV2mng6F
{
  char_T f1[6];
  char_T f2[5];
  char_T f3[4];
  char_T f4[7];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[5];
};

#endif                                 /* struct_c4_tag_WYClaNMLzsYbJFiV2mng6F */

#ifndef typedef_c4_cell_10
#define typedef_c4_cell_10

typedef struct c4_tag_WYClaNMLzsYbJFiV2mng6F c4_cell_10;

#endif                                 /* typedef_c4_cell_10 */

#ifndef struct_c4_tag_L5JvjW1A13FyCQi5N783sB
#define struct_c4_tag_L5JvjW1A13FyCQi5N783sB

struct c4_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* struct_c4_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef typedef_c4_cell_wrap_0
#define typedef_c4_cell_wrap_0

typedef struct c4_tag_L5JvjW1A13FyCQi5N783sB c4_cell_wrap_0;

#endif                                 /* typedef_c4_cell_wrap_0 */

#ifndef struct_c4_tag_BoX4lGjW7CLGNTo2OWmlp
#define struct_c4_tag_BoX4lGjW7CLGNTo2OWmlp

struct c4_tag_BoX4lGjW7CLGNTo2OWmlp
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[7];
};

#endif                                 /* struct_c4_tag_BoX4lGjW7CLGNTo2OWmlp */

#ifndef typedef_c4_cell_11
#define typedef_c4_cell_11

typedef struct c4_tag_BoX4lGjW7CLGNTo2OWmlp c4_cell_11;

#endif                                 /* typedef_c4_cell_11 */

#ifndef struct_c4_tag_6CsBRVljdCQyAxGT7eZM3E
#define struct_c4_tag_6CsBRVljdCQyAxGT7eZM3E

struct c4_tag_6CsBRVljdCQyAxGT7eZM3E
{
  char_T f1[7];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[7];
  char_T f6[8];
};

#endif                                 /* struct_c4_tag_6CsBRVljdCQyAxGT7eZM3E */

#ifndef typedef_c4_cell_12
#define typedef_c4_cell_12

typedef struct c4_tag_6CsBRVljdCQyAxGT7eZM3E c4_cell_12;

#endif                                 /* typedef_c4_cell_12 */

#ifndef struct_c4_tag_URxaCoPZWr69Oy7fwnFxl
#define struct_c4_tag_URxaCoPZWr69Oy7fwnFxl

struct c4_tag_URxaCoPZWr69Oy7fwnFxl
{
  char_T f1[5];
  char_T f2[4];
  char_T f3[6];
  char_T f4[5];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* struct_c4_tag_URxaCoPZWr69Oy7fwnFxl */

#ifndef typedef_c4_cell_14
#define typedef_c4_cell_14

typedef struct c4_tag_URxaCoPZWr69Oy7fwnFxl c4_cell_14;

#endif                                 /* typedef_c4_cell_14 */

#ifndef struct_c4_tag_yMfj6323Zqv19VFnWGoHjH
#define struct_c4_tag_yMfj6323Zqv19VFnWGoHjH

struct c4_tag_yMfj6323Zqv19VFnWGoHjH
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[6];
};

#endif                                 /* struct_c4_tag_yMfj6323Zqv19VFnWGoHjH */

#ifndef typedef_c4_cell_15
#define typedef_c4_cell_15

typedef struct c4_tag_yMfj6323Zqv19VFnWGoHjH c4_cell_15;

#endif                                 /* typedef_c4_cell_15 */

#ifndef struct_c4_tag_9SoYFOHTFNVnYR44IKzdJH
#define struct_c4_tag_9SoYFOHTFNVnYR44IKzdJH

struct c4_tag_9SoYFOHTFNVnYR44IKzdJH
{
  char_T f1[2];
  char_T f2[9];
  char_T f3[4];
};

#endif                                 /* struct_c4_tag_9SoYFOHTFNVnYR44IKzdJH */

#ifndef typedef_c4_cell_17
#define typedef_c4_cell_17

typedef struct c4_tag_9SoYFOHTFNVnYR44IKzdJH c4_cell_17;

#endif                                 /* typedef_c4_cell_17 */

#ifndef struct_c4_tag_fmW94SyqNuqwvLGV2qfkpE
#define struct_c4_tag_fmW94SyqNuqwvLGV2qfkpE

struct c4_tag_fmW94SyqNuqwvLGV2qfkpE
{
  char_T f1[5];
  char_T f2[7];
  char_T f3[7];
  char_T f4[17];
  char_T f5[22];
};

#endif                                 /* struct_c4_tag_fmW94SyqNuqwvLGV2qfkpE */

#ifndef typedef_c4_cell_16
#define typedef_c4_cell_16

typedef struct c4_tag_fmW94SyqNuqwvLGV2qfkpE c4_cell_16;

#endif                                 /* typedef_c4_cell_16 */

#ifndef struct_c4_tag_ps6xcYPd6Y7F0F1cJs8YU
#define struct_c4_tag_ps6xcYPd6Y7F0F1cJs8YU

struct c4_tag_ps6xcYPd6Y7F0F1cJs8YU
{
  char_T f1[5];
  char_T f2[7];
  char_T f3[17];
  char_T f4[22];
};

#endif                                 /* struct_c4_tag_ps6xcYPd6Y7F0F1cJs8YU */

#ifndef typedef_c4_cell_18
#define typedef_c4_cell_18

typedef struct c4_tag_ps6xcYPd6Y7F0F1cJs8YU c4_cell_18;

#endif                                 /* typedef_c4_cell_18 */

#ifndef struct_c4_tag_xrIszVtjD7x2xDQJhvqr2E
#define struct_c4_tag_xrIszVtjD7x2xDQJhvqr2E

struct c4_tag_xrIszVtjD7x2xDQJhvqr2E
{
  char_T f1[8];
  char_T f2[5];
  char_T f3[7];
  char_T f4[9];
  char_T f5[3];
  char_T f6[7];
  char_T f7[7];
  char_T f8[4];
  char_T f9[6];
};

#endif                                 /* struct_c4_tag_xrIszVtjD7x2xDQJhvqr2E */

#ifndef typedef_c4_cell_19
#define typedef_c4_cell_19

typedef struct c4_tag_xrIszVtjD7x2xDQJhvqr2E c4_cell_19;

#endif                                 /* typedef_c4_cell_19 */

#ifndef struct_c4_tag_tP4ysjhyvuYk36JuHDg8bD
#define struct_c4_tag_tP4ysjhyvuYk36JuHDg8bD

struct c4_tag_tP4ysjhyvuYk36JuHDg8bD
{
  c4_s_a7TcNrdk5JZcy5uxGijaRG _data;
};

#endif                                 /* struct_c4_tag_tP4ysjhyvuYk36JuHDg8bD */

#ifndef typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD
#define typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c4_tag_tP4ysjhyvuYk36JuHDg8bD c4_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* typedef_c4_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef struct_c4_tag_ynaaIE6q9xznGBkza31TCF
#define struct_c4_tag_ynaaIE6q9xznGBkza31TCF

struct c4_tag_ynaaIE6q9xznGBkza31TCF
{
  c4_cell_1 _data;
};

#endif                                 /* struct_c4_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c4_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c4_s_ynaaIE6q9xznGBkza31TCF

typedef struct c4_tag_ynaaIE6q9xznGBkza31TCF c4_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c4_s_ynaaIE6q9xznGBkza31TCF */

#ifndef struct_c4_tag_y30bjXPnZrp2waraWnJSvH
#define struct_c4_tag_y30bjXPnZrp2waraWnJSvH

struct c4_tag_y30bjXPnZrp2waraWnJSvH
{
  c4_cell_2 _data;
};

#endif                                 /* struct_c4_tag_y30bjXPnZrp2waraWnJSvH */

#ifndef typedef_c4_s_y30bjXPnZrp2waraWnJSvH
#define typedef_c4_s_y30bjXPnZrp2waraWnJSvH

typedef struct c4_tag_y30bjXPnZrp2waraWnJSvH c4_s_y30bjXPnZrp2waraWnJSvH;

#endif                                 /* typedef_c4_s_y30bjXPnZrp2waraWnJSvH */

#ifndef struct_c4_tag_lFc4yenLpnRlydRiCMxaZD
#define struct_c4_tag_lFc4yenLpnRlydRiCMxaZD

struct c4_tag_lFc4yenLpnRlydRiCMxaZD
{
  c4_cell_3 _data;
};

#endif                                 /* struct_c4_tag_lFc4yenLpnRlydRiCMxaZD */

#ifndef typedef_c4_s_lFc4yenLpnRlydRiCMxaZD
#define typedef_c4_s_lFc4yenLpnRlydRiCMxaZD

typedef struct c4_tag_lFc4yenLpnRlydRiCMxaZD c4_s_lFc4yenLpnRlydRiCMxaZD;

#endif                                 /* typedef_c4_s_lFc4yenLpnRlydRiCMxaZD */

#ifndef struct_c4_tag_BrRdqYMft44ulwR1A7rKqF
#define struct_c4_tag_BrRdqYMft44ulwR1A7rKqF

struct c4_tag_BrRdqYMft44ulwR1A7rKqF
{
  c4_cell_wrap_4 _data;
};

#endif                                 /* struct_c4_tag_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c4_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c4_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c4_tag_BrRdqYMft44ulwR1A7rKqF c4_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c4_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef struct_c4_tag_zhWislg2JXfOJCG0FlayVG
#define struct_c4_tag_zhWislg2JXfOJCG0FlayVG

struct c4_tag_zhWislg2JXfOJCG0FlayVG
{
  c4_cell_5 _data;
};

#endif                                 /* struct_c4_tag_zhWislg2JXfOJCG0FlayVG */

#ifndef typedef_c4_s_zhWislg2JXfOJCG0FlayVG
#define typedef_c4_s_zhWislg2JXfOJCG0FlayVG

typedef struct c4_tag_zhWislg2JXfOJCG0FlayVG c4_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* typedef_c4_s_zhWislg2JXfOJCG0FlayVG */

#ifndef struct_c4_tag_lnEOVMt12CNg5nSw1iwvNF
#define struct_c4_tag_lnEOVMt12CNg5nSw1iwvNF

struct c4_tag_lnEOVMt12CNg5nSw1iwvNF
{
  c4_cell_wrap_6 _data;
};

#endif                                 /* struct_c4_tag_lnEOVMt12CNg5nSw1iwvNF */

#ifndef typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF
#define typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c4_tag_lnEOVMt12CNg5nSw1iwvNF c4_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* typedef_c4_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef struct_c4_tag_Uq8YUzQmSy3K1TONPeIAhC
#define struct_c4_tag_Uq8YUzQmSy3K1TONPeIAhC

struct c4_tag_Uq8YUzQmSy3K1TONPeIAhC
{
  c4_cell_7 _data;
};

#endif                                 /* struct_c4_tag_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC
#define typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c4_tag_Uq8YUzQmSy3K1TONPeIAhC c4_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* typedef_c4_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef struct_c4_tag_i8jNnI3x8wo4JAox5HV9WF
#define struct_c4_tag_i8jNnI3x8wo4JAox5HV9WF

struct c4_tag_i8jNnI3x8wo4JAox5HV9WF
{
  c4_cell_8 _data;
};

#endif                                 /* struct_c4_tag_i8jNnI3x8wo4JAox5HV9WF */

#ifndef typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF
#define typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c4_tag_i8jNnI3x8wo4JAox5HV9WF c4_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* typedef_c4_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef struct_c4_tag_dV11HShs2d9BqwRJb6HgvD
#define struct_c4_tag_dV11HShs2d9BqwRJb6HgvD

struct c4_tag_dV11HShs2d9BqwRJb6HgvD
{
  c4_cell_9 _data;
};

#endif                                 /* struct_c4_tag_dV11HShs2d9BqwRJb6HgvD */

#ifndef typedef_c4_s_dV11HShs2d9BqwRJb6HgvD
#define typedef_c4_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c4_tag_dV11HShs2d9BqwRJb6HgvD c4_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* typedef_c4_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef struct_c4_tag_HSHOljOSgF7qDZeWd2IfH
#define struct_c4_tag_HSHOljOSgF7qDZeWd2IfH

struct c4_tag_HSHOljOSgF7qDZeWd2IfH
{
  c4_cell_10 _data;
};

#endif                                 /* struct_c4_tag_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c4_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c4_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c4_tag_HSHOljOSgF7qDZeWd2IfH c4_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c4_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef struct_c4_tag_HOps0FrfA6RiWumqewPwZD
#define struct_c4_tag_HOps0FrfA6RiWumqewPwZD

struct c4_tag_HOps0FrfA6RiWumqewPwZD
{
  c4_cell_wrap_0 _data;
};

#endif                                 /* struct_c4_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c4_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c4_s_HOps0FrfA6RiWumqewPwZD

typedef struct c4_tag_HOps0FrfA6RiWumqewPwZD c4_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c4_s_HOps0FrfA6RiWumqewPwZD */

#ifndef struct_c4_tag_23YJI910RYCWhAsXw5RjrG
#define struct_c4_tag_23YJI910RYCWhAsXw5RjrG

struct c4_tag_23YJI910RYCWhAsXw5RjrG
{
  c4_cell_11 _data;
};

#endif                                 /* struct_c4_tag_23YJI910RYCWhAsXw5RjrG */

#ifndef typedef_c4_s_23YJI910RYCWhAsXw5RjrG
#define typedef_c4_s_23YJI910RYCWhAsXw5RjrG

typedef struct c4_tag_23YJI910RYCWhAsXw5RjrG c4_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* typedef_c4_s_23YJI910RYCWhAsXw5RjrG */

#ifndef struct_c4_tag_i3ZGqykvgqQLsMCH6x4OBH
#define struct_c4_tag_i3ZGqykvgqQLsMCH6x4OBH

struct c4_tag_i3ZGqykvgqQLsMCH6x4OBH
{
  c4_cell_12 _data;
};

#endif                                 /* struct_c4_tag_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c4_tag_i3ZGqykvgqQLsMCH6x4OBH c4_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c4_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef struct_c4_tag_u4ui3JwwaZ1jYzDQeNl7gB
#define struct_c4_tag_u4ui3JwwaZ1jYzDQeNl7gB

struct c4_tag_u4ui3JwwaZ1jYzDQeNl7gB
{
  c4_cell_14 _data;
};

#endif                                 /* struct_c4_tag_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB
#define typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c4_tag_u4ui3JwwaZ1jYzDQeNl7gB c4_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* typedef_c4_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef struct_c4_tag_lv60kHidgCVN68cHDjBCkF
#define struct_c4_tag_lv60kHidgCVN68cHDjBCkF

struct c4_tag_lv60kHidgCVN68cHDjBCkF
{
  c4_cell_15 _data;
};

#endif                                 /* struct_c4_tag_lv60kHidgCVN68cHDjBCkF */

#ifndef typedef_c4_s_lv60kHidgCVN68cHDjBCkF
#define typedef_c4_s_lv60kHidgCVN68cHDjBCkF

typedef struct c4_tag_lv60kHidgCVN68cHDjBCkF c4_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* typedef_c4_s_lv60kHidgCVN68cHDjBCkF */

#ifndef struct_c4_tag_fnNBZRcViWKJIkyfK13VxD
#define struct_c4_tag_fnNBZRcViWKJIkyfK13VxD

struct c4_tag_fnNBZRcViWKJIkyfK13VxD
{
  c4_cell_17 _data;
};

#endif                                 /* struct_c4_tag_fnNBZRcViWKJIkyfK13VxD */

#ifndef typedef_c4_s_fnNBZRcViWKJIkyfK13VxD
#define typedef_c4_s_fnNBZRcViWKJIkyfK13VxD

typedef struct c4_tag_fnNBZRcViWKJIkyfK13VxD c4_s_fnNBZRcViWKJIkyfK13VxD;

#endif                                 /* typedef_c4_s_fnNBZRcViWKJIkyfK13VxD */

#ifndef struct_c4_tag_aArV2XTcNncafn1rtkY7sE
#define struct_c4_tag_aArV2XTcNncafn1rtkY7sE

struct c4_tag_aArV2XTcNncafn1rtkY7sE
{
  c4_cell_16 _data;
};

#endif                                 /* struct_c4_tag_aArV2XTcNncafn1rtkY7sE */

#ifndef typedef_c4_s_aArV2XTcNncafn1rtkY7sE
#define typedef_c4_s_aArV2XTcNncafn1rtkY7sE

typedef struct c4_tag_aArV2XTcNncafn1rtkY7sE c4_s_aArV2XTcNncafn1rtkY7sE;

#endif                                 /* typedef_c4_s_aArV2XTcNncafn1rtkY7sE */

#ifndef struct_c4_tag_2BS9SxHF6FwtuvnmplIf4D
#define struct_c4_tag_2BS9SxHF6FwtuvnmplIf4D

struct c4_tag_2BS9SxHF6FwtuvnmplIf4D
{
  c4_cell_18 _data;
};

#endif                                 /* struct_c4_tag_2BS9SxHF6FwtuvnmplIf4D */

#ifndef typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D
#define typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D

typedef struct c4_tag_2BS9SxHF6FwtuvnmplIf4D c4_s_2BS9SxHF6FwtuvnmplIf4D;

#endif                                 /* typedef_c4_s_2BS9SxHF6FwtuvnmplIf4D */

#ifndef struct_c4_tag_IZ4td7h7wPpJ1lGa4DnYYF
#define struct_c4_tag_IZ4td7h7wPpJ1lGa4DnYYF

struct c4_tag_IZ4td7h7wPpJ1lGa4DnYYF
{
  c4_cell_19 _data;
};

#endif                                 /* struct_c4_tag_IZ4td7h7wPpJ1lGa4DnYYF */

#ifndef typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF
#define typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF

typedef struct c4_tag_IZ4td7h7wPpJ1lGa4DnYYF c4_s_IZ4td7h7wPpJ1lGa4DnYYF;

#endif                                 /* typedef_c4_s_IZ4td7h7wPpJ1lGa4DnYYF */

#ifndef typedef_SFc4_flightControlSystemInstanceStruct
#define typedef_SFc4_flightControlSystemInstanceStruct

typedef struct {
  boolean_T c4_doneDoubleBufferReInit;
  uint8_T c4_is_active_c4_flightControlSystem;
  uint8_T c4_JITStateAnimation[1];
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c4_JITTransitionAnimation[1];
  int32_T c4_sfEvent;
  int32_T c4_IsDebuggerActive;
  int32_T c4_IsSequenceViewerPresent;
  int32_T c4_SequenceViewerOptimization;
  int32_T c4_IsHeatMapPresent;
  void *c4_RuntimeVar;
  uint32_T c4_mlFcnLineNumber;
  void *c4_fcnDataPtrs[18];
  char_T *c4_dataNames[18];
  uint32_T c4_numFcnVars;
  uint32_T c4_ssIds[18];
  uint32_T c4_statuses[18];
  void *c4_outMexFcns[18];
  void *c4_inMexFcns[18];
  real_T c4_bordesRGB[57600];
  real_T c4_bordes_martix[19200];
  real_T c4_Gdir[19200];
  real_T c4_Gx[19200];
  real_T c4_Gy[19200];
  real_T c4_y[19200];
  real_T c4_a[19764];
  real_T c4_im[19200];
  real_T c4_dv[57600];
  real_T c4_b_dv[57600];
  real32_T c4_b_a[21120];
  real32_T c4_c_a[20640];
  real32_T c4_d_a[19200];
  real32_T c4_i1[19200];
  CovrtStateflowInstance *c4_covrtInstance;
  void *c4_fEmlrtCtx;
  boolean_T (*c4_BW)[19200];
  real_T *c4_direction;
  real_T (*c4_b_bordesRGB)[57600];
} SFc4_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc4_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c4_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c4_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c4_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
